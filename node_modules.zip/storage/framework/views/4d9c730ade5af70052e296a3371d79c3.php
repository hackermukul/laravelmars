<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="shortcut icon" href="<?php echo e(config('constants.options.__IMAGE__').'rad.png'); ?>" type="image/x-icon">
<link rel="icon" href="<?php echo e(config('constants.options.__IMAGE__').'rad.png'); ?>" type="image/x-icon">
<!-- <title><?php echo e(config('constants.options._project_name_', 'College Management')); ?></title> -->
<title><?php echo e(config('constants.options._project_name_', 'College Management')); ?> | <?php echo $__env->yieldContent('title'); ?>  </title>

<!-- CSS here -->
<link rel="stylesheet" href="<?php echo e(config('constants.options.Website_Files').'css/bootstrap.min.css'); ?>" />
<link rel="stylesheet" href="<?php echo e(config('constants.options.Website_Files').'css/animate.min.css'); ?>" />
<link rel="stylesheet" href="<?php echo e(config('constants.options.Website_Files').'fontawesome/css/all.min.css'); ?>" />
<link rel="stylesheet" href="<?php echo e(config('constants.options.Website_Files').'css/dripicons.css'); ?>" />
<link rel="stylesheet" href="<?php echo e(config('constants.options.Website_Files').'css/slick.css'); ?>" />
<link rel="stylesheet" href="<?php echo e(config('constants.options.Website_Files').'css/meanmenu.css'); ?>" />
<link rel="stylesheet" href="<?php echo e(config('constants.options.Website_Files').'css/default.css'); ?>" />
<link rel="stylesheet" href="<?php echo e(config('constants.options.Website_Files').'css/style.css'); ?> " />
<link rel="stylesheet" href="<?php echo e(config('constants.options.Website_Files').'css/responsive.css'); ?> " />
<link rel="stylesheet" href="<?php echo e(url()->current()); ?>assets/front/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/front/css/animate.min.css">
<link rel="stylesheet" href="assets/front/css/magnific-popup.css">
<link rel="stylesheet" href="assets/front/fontawesome/css/all.min.css">
<link rel="stylesheet" href="assets/front/css/dripicons.css">
<link rel="stylesheet" href="assets/front/css/slick.css">
<link rel="stylesheet" href="assets/front/css/meanmenu.css">
<link rel="stylesheet" href="assets/front/css/default.css">
<link rel="stylesheet" href="assets/front/css/style.css">
<link rel="stylesheet" href="assets/front/css/responsive.css">
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.bunny.net">
<link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
<?php /**PATH C:\xampp\htdocs\laravelmars\resources\views/components/partials/head.blade.php ENDPATH**/ ?>