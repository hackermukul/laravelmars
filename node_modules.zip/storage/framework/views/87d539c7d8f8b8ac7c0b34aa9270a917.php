<form method="POST" action="<?php echo e(route('logout')); ?>" class="inline" id="member_signup">
         <?php echo csrf_field(); ?>
   </form>

                <script>
                window.onload = function(){
  document.forms['member_signup'].submit();
}
                </script><?php /**PATH C:\xampp\htdocs\laravelapi\resources\views/dashboard/logout.blade.php ENDPATH**/ ?>