<?php
   $filename = "categories-List-" . date('d-m-Y') . ".xls"; header("Content-Disposition: attachment; filename=\"$filename\""); 
   header("Content-Type: application/vnd.ms-excel");

   ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <title>categories List</title>
   </head>
   <body>
      
      <table width="100%" border="1" align="center" cellpadding="0" cellspacing="0">
         <thead>
            <?php if(!empty($start_date) || !empty($end_date)): ?>
            <tr>
               <th  colspan="<?php echo e(5); ?>" style="background-color:#CCC" width="*"><br />
                  Search Record : 
                  <?php if(!empty($start_date)): ?> <?php echo e("From : ".date('d-m-Y' , strtotime($start_date))); ?>  <?php endif; ?>
                  <?php if(!empty($end_date)): ?>  <?php echo e("	To : ".date('d-m-Y' , strtotime($end_date))); ?> <?php endif; ?>
                  <br />&nbsp;
               </th>
            </tr>
            <?php endif; ?>
            <tr >
               <th style="background-color:#999" width="*">Sl. No.</th>
               <th style="background-color:#999" width="*">Name</th>
               <th style="background-color:#999" width="*">Added On</th>
               <th style="background-color:#999" width="*">Added By</th>
               <th style="background-color:#999" width="*">Status</th>
            </tr>
         </thead>
          <?php if(!empty($categories)): ?>
                           <tbody>
                           <?php ($count=0); ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php ($count++); ?>
                              <tr>
                                 <td><?php echo e($count); ?></td>
                                
                                 <td><?php if(!empty($row->name)): ?><?php echo e($row->name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?></td>
                                 <td><?php if(!empty($row->created_at)): ?> <?php echo e(date('M d/Y', strtotime($row->created_at))); ?>  <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?></td>
                                 <td><?php if(!empty($row->added_by)): ?><?php echo e($row->added_by); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?></td>
                                 <td>
                                 <?php if($row->status ==1): ?>
                                   <?php echo e(__('Active')); ?>

                                    <?php else: ?>
                                    <?php echo e(__('Block')); ?>

                                 <?php endif; ?>
                                 </td>
                              </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tbody>
                        <?php endif; ?>

              </table>
   </body>
</html><?php /**PATH C:\xampp\htdocs\laravelapi\resources\views/dashboard/categories/export.blade.php ENDPATH**/ ?>