<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1 class="m-0 text-dark"><?php if($page_module_name != '' ): ?> <?php echo e($page_module_name); ?> <?php else: ?> <?php echo e('NONE'); ?> <?php endif; ?> </h1>
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="">Home</a></li>
               <li class="breadcrumb-item"><a href="<?php echo e(route($main_routes.'.index')); ?>">  <?php if($page_module_name != '' ): ?> <?php echo e($page_module_name); ?> <?php else: ?> <?php echo e('NONE'); ?> <?php endif; ?>  List</a></li>
               <li class="breadcrumb-item">Add New Record</li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>

<section class="content">
    <div class="row">
        <div class="col-12">
            <div class="card">
               <div class="card-header">
                  <h3 class="card-title"><?php if($data_view[0]->name): ?> <?php echo e($data_view[0]->name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?></h3>
                  <div class="float-right">
                  
                     <a href="<?php echo e(route($main_routes.'.edit', $data_view[0]->slug)); ?>"> 
                     <button type="button" class="btn btn-success btn-sm"><i class="fas fa-edit"></i> Update</button>
                     </a>
                     
                  </div>
               </div>
                <!-- /.card-header -->
                <div class="card-body card-primary card-outline">
                    <form action="" name="ptype_list_form" method="post" class="form-horizontal" role="form">
                        <input type="hidden" name="task" id="task" value="" />

                        <table id="" class="table table-bordered table-hover myviewtable responsiveTableNewDesign">
                            <tbody>
                                <tr>
                                    <td>
                                        <strong class="full">Data Base Id</strong>
                                         <?php if($data_view[0]->id): ?> <?php echo e($data_view[0]->id); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>   
                                    </td>
                                    <td>
                                        <strong class="full">College Unique Name</strong>
                                        <?php if($data_view[0]->unique_name): ?> <?php echo e($data_view[0]->unique_name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>                                   
                                    </td>
                                    <td>
                                        <strong class="full">College Name</strong>
                                         <?php if($data_view[0]->name): ?> <?php echo e($data_view[0]->name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 
                                    </td>
                                    <td>
                                        <strong class="full">College Website</strong>
                                       <?php if($data_view[0]->website): ?> <?php echo e($data_view[0]->website); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 
                                    </td>
                                    <td>
                                        <strong class="full">College Email</strong>
                                       <?php if($data_view[0]->email): ?> <?php echo e($data_view[0]->email); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <strong class="full">Name</strong>
                                       <?php if($data_view[0]->first_name): ?> <?php echo e($data_view[0]->first_name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 
                                    </td>
                                    <td>
                                        <strong class="full">Email Id</strong>
                                       <?php if($data_view[0]->email): ?> <?php echo e($data_view[0]->email); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 
                                    </td>
                                    <td>
                                        <strong class="full">Mobile No</strong>
                                         <?php if($data_view[0]->mobile_no): ?> <?php echo e($data_view[0]->mobile_no); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 

                                    </td>
                                    <td>
                                        <strong class="full">Alt Mobile No</strong>
                                       <?php if($data_view[0]->alt_mobile_no): ?> <?php echo e($data_view[0]->alt_mobile_no); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 

                                    </td>
                                    <td>
                                        <strong class="full">College Description</strong>
                                       <?php if($data_view[0]->short_description): ?> <?php echo e($data_view[0]->short_description); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <strong class="full">Address</strong>
                                         <?php if($data_view[0]->address1): ?> <?php echo e($data_view[0]->address1); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 

                                    </td>
                                    <td>
                                        <strong class="full">Country</strong>
                                         <?php if($data_view[0]->country_name): ?> <?php echo e($data_view[0]->country_name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 

                                    </td>
                                     <td>
                                        <strong class="full">State</strong>
                                         <?php if($data_view[0]->state_name): ?> <?php echo e($data_view[0]->state_name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 

                                    </td>
                                     <td>
                                        <strong class="full">City</strong>
                                         <?php if($data_view[0]->city_name): ?> <?php echo e($data_view[0]->city_name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> 

                                    </td>
                                    <td>
                                        <strong class="full">Logo</strong>
                                        <span class="pip">
                                            <a target="_blank" href="https://dietdighi.in/assets/upload/company_profile/logo/logo_1.jpg">
                                                <img class="imageThumb" src="https://dietdighi.in/assets/upload/company_profile/logo/logo_1.jpg" style="width: 50px;" />
                                            </a>
                                        </span>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <strong class="full">Added On</strong>
                                          <?php if(!empty($data_view[0]->created_at)): ?> <?php echo e(date('d-m-Y H:i:s A', strtotime($data_view[0]->created_at))); ?>  <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>                               

                                    </td>
                                    <td>
                                        <strong class="full">Added By</strong>
                                       <?php if($data_view[0]->added_by_name): ?> <?php echo e($data_view[0]->added_by_name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>                                      

                                    </td>
                                    <td>
                                        <strong class="full">Updated On</strong>
                                          <?php if(!empty($data_view[0]->updated_at)): ?> <?php echo e(date('d-m-Y H:i:s A', strtotime($data_view[0]->updated_at))); ?>  <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>                               
                                    </td>
                                    <td>
                                        <strong class="full">Updated By</strong>
                                     <?php if($data_view[0]->updated_by_name): ?> <?php echo e($data_view[0]->updated_by_name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>                                      

                                    </td>
                                    <td>
                                        <strong class="full">Status</strong>
                                        <?php if($data_view[0]->status ==1): ?>
                                    <i class="fas fa-check btn-success btn-sm "></i>Active
                                    <?php else: ?>
                                    <i class="fas fa-ban btn-danger btn-sm "></i>Block
                                 <?php endif; ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </form>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
    </div>
</section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravelapi\resources\views/dashboard/company/show.blade.php ENDPATH**/ ?>