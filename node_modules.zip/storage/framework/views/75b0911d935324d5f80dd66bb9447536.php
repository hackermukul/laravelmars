<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

   <div class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6">
               <h1 class="m-0 text-dark"> <?php if($page_module_name != '' ): ?> <?php echo e($page_module_name); ?> <?php else: ?> <?php echo e('NONE'); ?> <?php endif; ?> <small>List</small></h1>
            </div>
            <!-- /.col -->
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>" :active="request()->routeIs('dashboard')">Home</a></li>
                  <li class="breadcrumb-item active"> <?php if($page_module_name != '' ): ?> <?php echo e($page_module_name); ?> <?php else: ?> <?php echo e('NONE'); ?> <?php endif; ?></li>
               </ol>
            </div>
            <!-- /.col -->
         </div>
         <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
   </div>
   <section class="content">
      <div class="row">
         <div class="col-12">
            <div id="accordion">
               <!-- we are adding the .class so bootstrap.js collapse plugin detects it -->
               <div class="card card-primary">
                  <div class="card-header">
                     <h4 class="card-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" class="collapsed" aria-expanded="false">
                        Search Panel
                        </a>
                     </h4>
                  </div>
                  <div id="collapseOne" class="panel-collapse collapse" style="">
                     <div class="card-body">                   
                        <form action="<?php echo e(route('categories.search')); ?>" method="post" id="search_report_form" name="search_report_form" style="" class="form-horizontal" role="form" accept-charset="utf-8">
                           <?php echo csrf_field(); ?>
                             <div class="card-body">
                              <div class="row">
                                 <div class="col-md-2">
                                    <div class="form-group">
                                       <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['for' => 'Category','class' => 'ccol-sm-12 label_content px-2 py-0','value' => ''.e(__('Field')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'Category','class' => 'ccol-sm-12 label_content px-2 py-0','value' => ''.e(__('Field')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                       <select name="field_name" id="field_name" title="Field" class="form-control" style="width:100%">
                                          <option value="urm.name" <?php echo e(old('field_name',$field_name)=="urm.name"? 'selected':''); ?> >Name</option>
                                       </select>
                                    </div>
                                 </div>
                                 <!-- /.col -->
                                 <div class="col-md-2">
                                    <div class="form-group">
                                       <label for="field_name">Field Value</label>
                                       <input type="text" name="field_value" value="<?php echo e($field_value); ?>" id="field_value" title="Field Value" class="form-control" style="width:100%">
                                    </div>
                                 </div>
                                 <div class="col-md-2">
                                    <div class="form-group">
                                       <label for="field_name">Start Date</label>
                                       <input type="date" name="start_date" id="start_date" title="Start Date" value="<?php echo e($start_date); ?>" class="form-control" style="width:100%">
                                    </div>
                                 </div>
                                 <!-- /.col -->
                                 <div class="col-md-2">
                                    <div class="form-group">
                                       <label for="field_name">End Date</label><input type="date" name="end_date" value="<?php echo e($end_date); ?>" id="end_date" title="End Date" value="<?php echo e($end_date); ?>" class="form-control">
                                    </div>
                                 </div>
                                 <div class="col-md-2">
                                    <div class="form-group">
                                       <label for="record_status">Status</label>
                                       <select name="record_status" id="record_status" title="Status" class="form-control" style="width:100%">
                                          <option value="" <?php echo e(old('record_status',$record_status)==""? 'selected':''); ?> >Active/Block</option>
                                          <option value="1" <?php echo e(old('record_status',$record_status)=="1"? 'selected':''); ?>>Active</option>
                                          <option value="zero" <?php echo e(old('record_status',$record_status)=="zero"? 'selected':''); ?>>Block</option>
                                       </select>
                                    </div>
                                 </div>
                              </div>
                              <div class="panel-footer">
                                 <center>
                                    <button type="submit" class="btn btn-info" id="search_report_btn" name="search_report_btn" value="1">Search</button>
                                    &nbsp;&nbsp;<button type="reset" class="btn btn-default">Reset</button>
                                 </center>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
               <div class="card">
                  <div class="card-header">
                     <h3 class="card-title"><span style="color:#FF0000;">Total Records: <?php echo e($row_count); ?></span></h3>
                     <div class="float-right">
                     
								<?php if($user_access->add_module==1): ?>	
                        <a href="<?php echo e(route('categories.create')); ?>"> 
                        <button type="button" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add
                        New</button></a>
                        <?php endif; ?>
                
							   <?php if($user_access->update_module==1): ?>
                        <a href="<?php echo e(route('categories.setPositions')); ?>"> 
                        <button type="button" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i>  Set Position
                         </button></a>
                        <button type="button" class="btn btn-success btn-sm" onclick="validateRecordsActivate()"><i class="fas fa-check"></i> Active</button>
                        <button type="button" class="btn btn-dark btn-sm" onclick="validateRecordsBlock()"><i class="fas fa-ban"></i> Block</button>
                        <?php endif; ?>

                        <?php if($user_access->export_data==1): ?>
                        <button type="button" class="btn btn-success btn-sm export_excel"><i class="fas fa-file-excel"></i> Export</button>
                        <?php endif; ?>
                        
                     </div>
                  </div>
                  <!-- /.card-header -->
                  <?php if(Session::has('success')): ?>
                     <div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><i class="icon fas fa-check"></i><?php echo e(Session::get('success')); ?> </div>
                  <?php elseif(Session::has('error')): ?>
                     <div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><i class="icon fas fa-ban"></i><?php echo e(Session::get('error')); ?> </div>
                  <?php endif; ?>

                  <?php if($user_access->view_module==1): ?>
                  <div class="card-body">
                     <form method="POST" action="<?php echo e(route('categories.updateStatus')); ?>"  id="ptype_list_form" name="ptype_list_form" style="" class="form-horizontal" role="form" enctype="multipart/form-data" accept-charset="utf-8">
                     <?php echo csrf_field(); ?>
                        <input type="hidden" name="task" id="task" value ="" />
                        <table id="example1" class="table table-bordered table-hover table-striped">
                           <thead>
                              <tr>
                                 <th>#</th>
                                 <th width="4%"><input type="checkbox" name="main_check" id="main_check"
                                    onclick="check_uncheck_All_records()" value="" /></th>
                                 <th>Name</th>
                                 <th>Added On</th>
                                 <th>Added By</th>
                                 <th>Updated By</th>
                                 <th>Status</th>
                              </tr>
                           </thead>
                          <?php if(!empty($categories)): ?>
                           <tbody>
                           <?php ($count=0); ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php ($count++); ?>
                              <tr>
                                 <td><?php echo e($count); ?></td>
                                 <td><input type="checkbox" name="sel_recds[]"
                                    id="sel_recds<?php echo e($count); ?>"
                                    value="<?php echo e($count); ?>" /></td>
                                 <td><a href="<?php echo e(route('categories.show', ['id' => $row->id])); ?>"><?php if(!empty($row->name)): ?><?php echo e($row->name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?> </a></td>
                                 <td><?php if(!empty($row->created_at)): ?> <?php echo e(date('M d/Y', strtotime($row->created_at))); ?>  <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?></td>
                                 <td><?php if(!empty($row->added_by_name)): ?><?php echo e($row->added_by_name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?></td>
                                 <td><?php if(!empty($row->updated_by_name)): ?><?php echo e($row->updated_by_name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?></td>

                                 <td>
                                 <?php if($row->status ==1): ?>
                                    <i class="fas fa-check btn-success btn-sm "></i>
                                    <?php else: ?>
                                    <i class="fas fa-ban btn-danger btn-sm "></i>
                                 <?php endif; ?>
                                 </td>
                              </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tbody>
                        <?php endif; ?>

                        </table>
                     </form>
                     <center>
                        <div class="pagination_custum"></div>
                     </center>
                  </div>
                  <?php else: ?>
                  <center>
                       <?php if (isset($component)) { $__componentOriginal09fcc4d8733e9303aba6fdb7626d3f6b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal09fcc4d8733e9303aba6fdb7626d3f6b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.denied','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('denied'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal09fcc4d8733e9303aba6fdb7626d3f6b)): ?>
<?php $attributes = $__attributesOriginal09fcc4d8733e9303aba6fdb7626d3f6b; ?>
<?php unset($__attributesOriginal09fcc4d8733e9303aba6fdb7626d3f6b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal09fcc4d8733e9303aba6fdb7626d3f6b)): ?>
<?php $component = $__componentOriginal09fcc4d8733e9303aba6fdb7626d3f6b; ?>
<?php unset($__componentOriginal09fcc4d8733e9303aba6fdb7626d3f6b); ?>
<?php endif; ?>
                  </center>                
                  <?php endif; ?>
                  <!-- /.card-body -->
               </div>
            </div>
         </div>
      </div>
   </section>
   <script type="application/javascript">
      function check_uncheck_All_records() // done
      {
          var mainCheckBoxObj = document.getElementById("main_check");
          var checkBoxObj = document.getElementsByName("sel_recds[]");
      
          for (var i = 0; i < checkBoxObj.length; i++) {
              if (mainCheckBoxObj.checked)
                  checkBoxObj[i].checked = true;
              else
                  checkBoxObj[i].checked = false;
          }
      }
      
      function validateCheckedRecordsArray() // done
      {
          var checkBoxObj = document.getElementsByName("sel_recds[]");
          var count = true;
      
          for (var i = 0; i < checkBoxObj.length; i++) {
              if (checkBoxObj[i].checked) {
                  count = false;
                  break;
              }
          }
      
          return count;
      }
      
      function validateRecordsActivate() // done
      {
          if (validateCheckedRecordsArray()) {
              //alert("Please select any record to activate.");
              toastrDefaultErrorFunc("Please select any record to activate.");
              document.getElementById("sel_recds1").focus();
              return false;
          } else {
              document.ptype_list_form.task.value = 'active';
              document.ptype_list_form.submit();
          }
      }
      
      function validateRecordsBlock() // done
      {
          if (validateCheckedRecordsArray()) {
              //alert("Please select any record to block.");
              toastrDefaultErrorFunc("Please select any record to block.");
              document.getElementById("sel_recds1").focus();
              return false;
          } else {
              document.ptype_list_form.task.value = 'block';
              document.ptype_list_form.submit();
          }
      }
   </script>
   <script>
window.addEventListener('load' , function(){

	$( ".paginationClass" ).click(function() {
		// console.log($(this).data('ci-pagination-page'));
		// console.log($(this));
		// console.log($(this).attr('href'));//alert();
		//alert(this.data('ci-pagination-page'));
		$('#search_report_form').attr('action', $(this).attr('href'));
		$('#search_report_form').submit();
		return false ;
	});
	$('#reservationdate').datetimepicker({
        format: 'DD-MM-YYYY'
	});
	$('#reservationdate1').datetimepicker({
        format: 'DD-MM-YYYY'
	});
	
	$(".export_excel").bind("click" , function(){
			
		$('#search_report_form').attr('action', '<?php echo e(route('categories.export-excel')); ?>');
		$('#search_report_form').attr('target', '_blank');
		$('#search_report_btn').click();
		
		$('#search_report_form').attr('action', 'https://dietdighi.in/setup/admin/master/Department-Module/department-list');
		$('#search_report_form').attr('target', '');
	})
})
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravelapi\resources\views/dashboard/categories/index.blade.php ENDPATH**/ ?>