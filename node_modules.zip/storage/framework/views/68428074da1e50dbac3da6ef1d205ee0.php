<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1 class="m-0 text-dark"><?php if($page_module_name != '' ): ?> <?php echo e($page_module_name); ?> <?php else: ?> <?php echo e('NONE'); ?> <?php endif; ?> </h1>
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="">Home</a></li>
               <li class="breadcrumb-item"><a href="<?php echo e(route($main_routes.'.index')); ?>">  <?php if($page_module_name != '' ): ?> <?php echo e($page_module_name); ?> <?php else: ?> <?php echo e('NONE'); ?> <?php endif; ?>  List</a></li>
               <li class="breadcrumb-item">Add New Record</li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<section class="content">
   <div class="row">
      <div class="col-12">
         <div class="card">
            <div class="card-header">
               <h3 class="card-title"><?php if($view_data[0]->name): ?> <?php echo e($view_data[0]->name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?></h3>
               <div class="float-right">
                  <a href="<?php echo e(route($main_routes.'.create')); ?>"> 
                  <button type="button" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add
                  New</button></a>
                  <a href="<?php echo e(route($main_routes.'.edit', $view_data[0]->slug)); ?>"> 
                  <button type="button" class="btn btn-success btn-sm"><i class="fas fa-edit"></i> Update</button>
                  </a>
                  
               </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
               <form action="" name="ptype_list_form" method="post" class="form-horizontal" role="form">
                  <input type="hidden" name="task" id="task" value="">
                  <div class="divTable">
                     <div class="TableRow">
                        <div class="table_col">
                           <label class="label_content_br">Data Base Id <span class="colen">:</span></label>
                            <?php if($view_data[0]->id): ?> <?php echo e($view_data[0]->id); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>                            
                        </div>
                        <div class="table_col">
                           <label class="label_content_br">Name <span class="colen">:</span></label>
                            <?php if($view_data[0]->name): ?> <?php echo e($view_data[0]->name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>                                   
                        </div>
                        
                        <div class="table_col">
                           <label class="label_content_br">Position <span class="colen">:</span></label>
                            <?php if($view_data[0]->position): ?> <?php echo e($view_data[0]->position); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>                                      
                                    
                        </div>
                        <div class="table_col">
                           <label class="label_content_br">Added On <span class="colen">:</span></label>
                          <?php if(!empty($view_data[0]->created_at)): ?> <?php echo e(date('d-m-Y H:i:s A', strtotime($view_data[0]->created_at))); ?>  <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>                               
                        </div>
                        <div class="table_col">
                           <label class="label_content_br">Country <span class="colen">:</span></label>
                          <?php if(!empty($view_data[0]->country_name)): ?> <?php echo e($view_data[0]->country_name); ?>  <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>                               
                        </div>
                     </div>
                     <div class="TableRow">
                        <div class="table_col">
                           <label class="label_content_br">Added By <span class="colen">:</span></label>
                            <?php if($view_data[0]->added_by_name): ?> <?php echo e($view_data[0]->added_by_name); ?> <?php else: ?> <?php echo e('N/A'); ?> <?php endif; ?>                                      
                                    
                        </div>
                        

                         
                        
                        <div class="table_col">
                           <label class="label_content_br">Status <span class="colen">:</span></label>
                             <?php if($view_data[0]->status ==1): ?>
                                    <i class="fas fa-check btn-success btn-sm "></i>Active
                                    <?php else: ?>
                                    <i class="fas fa-ban btn-danger btn-sm "></i>Block
                                 <?php endif; ?>
                        </div>
                     </div>
                  </div>
                  <table id="" class="table table-bordered table-hover myviewtable" style="display:none;">
                     <tbody>
                        <tr>
                           <td>
                              <strong class="full">Data Base Id</strong>
                              <?php echo e($view_data[0]->id); ?>

                           </td>
                           <td>
                              <strong class="full">view_data</strong>
                              
                           </td>
                           <td>
                              <strong class="full">Short Name</strong>
                              92
                           </td>
                           <td>
                              <strong class="full">view_data Code</strong>
                              012
                           </td>
                           <td>
                              <strong class="full">Added On</strong>
                              10-10-2023 11:48:18 PM
                           </td>
                           <td>
                              <strong class="full">Added By</strong>
                              test
                           </td>
                           <td>
                              <strong class="full">Updated On</strong>
                              17-08-2024 03:59:44 PM
                           </td>
                           <td>
                              <strong class="full">Updated By</strong>
                              test
                           </td>
                           <td>
                              <strong class="full">Status</strong>
                              Block <i class="fas fa-ban btn-danger btn-sm "></i> Block
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </form>
            </div>
            <!-- /.card-body -->
         </div>
      </div>
   </div>
</section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravelapi\resources\views/dashboard/city/show.blade.php ENDPATH**/ ?>