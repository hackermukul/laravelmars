
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <div class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6">
               <h1 class="m-0 text-dark">  <?php if($page_module_name != '' ): ?> <?php echo e($page_module_name); ?> <?php else: ?> <?php echo e('NONE'); ?> <?php endif; ?></h1>
            </div>
            <!-- /.col -->
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="">Home</a></li>
                  <li class="breadcrumb-item"><a href="<?php echo e(route($main_routes.'.index')); ?>"><?php if($page_module_name != '' ): ?> <?php echo e($page_module_name); ?> <?php else: ?> <?php echo e('NONE'); ?> <?php endif; ?>  List</a></li>
                  <li class="breadcrumb-item">Add New Record</li>
               </ol>
            </div>
            <!-- /.col -->
         </div>
         <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
   </div>
   <section class="content">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header">
                  <h3 class="card-title"> <small>Add New Record</small></h3>
               </div>
               <?php if(Session::has('success')): ?>
                     <div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><i class="icon fas fa-check"></i><?php echo e(Session::get('success')); ?> </div>
                  <?php elseif(Session::has('error')): ?>
                     <div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><i class="icon fas fa-ban"></i><?php echo e(Session::get('error')); ?> </div>
                  <?php endif; ?>
               <!-- /.card-header -->
               <div class="card-body">
                    <form method="POST" action="<?php echo e(route($main_routes.'.store')); ?>"  id="ptype_list_form" name="ptype_list_form" style="" class="form-horizontal" role="form" enctype="multipart/form-data" accept-charset="utf-8">
                     <?php echo csrf_field(); ?>
                    <input type="hidden" name="category_id" id="category_id" value="">
                     <input type="hidden" name="redirect_type" id="redirect_type" value="">  <input type="hidden" name="id" value="0" id="id">
                     <input type="hidden" name="redirect_type" value="" id="redirect_type">
                     <div class="">
                        <div class="">
                        <div class="form-group row">
                           <label for="inputEmail3" class="col-sm-2 col-form-label-lg">User Role Name </label>
                           <div class="col-sm-10">
                              <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['id' => 'name','class' => 'block mt-1 w-full','type' => 'text','name' => 'name','value' => old('name'),'required' => true,'placeholder' => 'Enter User Role Name','autofocus' => true,'autocomplete' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'name','class' => 'block mt-1 w-full','type' => 'text','name' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name')),'required' => true,'placeholder' => 'Enter User Role Name','autofocus' => true,'autocomplete' => 'name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                              <span style="color:#f00;font-size: 22px;margin-top: 3px;">*</span>
                                 <span>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error" style="color: red"><?php echo e($errors); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </span>
                           </div>
                        </div>
                        <div class="form-group row ">
                           <table id="" class="table table-bordered table-hover" style="font-size:medium" >
                              <thead>
                                 <tr>
                                    <th>#</th>
                                    <th>Role</th>
                                    <th>All</th>
                                    <th>View</th>
                                    <th>Add</th>
                                    <th>Update</th>
                                    <th style="display:none">Import</th>
                                    <th >Export</th>
                                 </tr>
                              </thead>
                              <tbody >
                                 <?php ($count=0); ?>
                                     <?php $__currentLoopData = $module_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php ($count++); ?>
                                 <?php echo e($all_checked = $view_checked = $add_checked = $update_checked = $delete_checked = $approval_checked = $import_checked = $export_checked =''); ?>

                                 <tr>
                                    <td><?php echo e($count); ?>.</td>
                                    <td><?php echo e($md->name); ?> [ <?php echo e($master_name[$md->is_master]); ?> ]</td>
                                    <td>
                                    	
                                       <input type="checkbox" value="<?php echo e($md->id); ?>" name="module_ids[]" class="module_all m_check_all_<?php echo e($md->id); ?>" data-module_id="<?php echo e($md->id); ?>"  data-bootstrap-switch data-off-color="danger" data-on-color="success" data-on-text="Yes" data-off-text="No" >

                                    </td>
                                    <td>
                                       <input type="checkbox" value="1" name="view_<?php echo e($md->id); ?>" class="module_field m_check_field_<?php echo e($md->id); ?>" data-module_id="<?php echo e($md->id); ?>" <?=$view_checked?> data-bootstrap-switch data-off-color="danger" data-on-color="success" data-on-text="Yes" data-off-text="No" >
                                    </td>
                                    <td>
                                       <input type="checkbox" value="1" name="add_<?php echo e($md->id); ?>" class="module_field m_check_field_<?php echo e($md->id); ?>" data-module_id="<?php echo e($md->id); ?>" <?=$add_checked?> data-bootstrap-switch data-off-color="danger" data-on-color="success" data-on-text="Yes" data-off-text="No" >
                                    </td>
                                    <td>
                                       <input type="checkbox" value="1" name="update_<?php echo e($md->id); ?>" class="module_field m_check_field_<?php echo e($md->id); ?>" data-module_id="<?php echo e($md->id); ?>" <?=$update_checked?> data-bootstrap-switch data-off-color="danger" data-on-color="success" data-on-text="Yes" data-off-text="No" >
                                    </td>
                                   
                                    <td>
                                       <input type="checkbox" value="1" name="export_<?php echo e($md->id); ?>" class="module_field m_check_field_<?php echo e($md->id); ?>" data-module_id="<?php echo e($md->id); ?>" <?=$export_checked?> data-bootstrap-switch data-off-color="danger" data-on-color="success" data-on-text="Yes" data-off-text="No" >
                                    </td>
                                 </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                           </table>
                        </div>
                        <div class="form-group row">
                           <label for="radioSuccess1" class="col-sm-2 col-form-label-lg">Status</label>
                           <div class="col-sm-10">
                              <div class="form-check" style="margin-top:12px">
                                 <div class="form-group clearfix">
                                    <div class="icheck-success d-inline">
                                       <input type="radio" name="status" value="1"  <?php echo e(old('status') == '1' ? 'checked' : 'checked'); ?> id="Active" required="required" class="label-active">
                                          <label for="Active"><?php echo e(__('Active')); ?></label>        
                                    </div>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <div class="icheck-danger d-inline">
                                       <input type="radio" name="status" value="0" <?php echo e(old('status') == '0' ? 'checked' : ''); ?> id="Block" required="required" class="label-block">
                                          <label for="Block"><?php echo e(__('Block')); ?></label>						<span>
                                          </span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                           <center>
                              <button type="submit" name="save" onclick="return redirect_type_func('')" value="save" class="btn btn-info"> <?php echo e(__('Save')); ?></button>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <button type="submit" name="save" onclick="return redirect_type_func('save-add-new')" value="save-add-new" class="btn btn-default "><?php echo e(__('Save And Add New')); ?></button>
                            </center>
                        </div>
                        <!-- /.card-footer -->
                     </div>
                  </form>
                  <!-- /.card-body -->
               </div>
            </div>
         </div>
      </div>
   </section>
   <script>
	function redirect_type_func(data)
	{
		document.getElementById("redirect_type").value = data;
		return true;
	}
window.addEventListener('load' , function(){
	var approve_all = false;	
	var approve_field = false;	
	$('.module_all').on('switchChange.bootstrapSwitch', function (event, state) {
		if(approve_field){return false;}
		console.log(state);
		var module_id = $(this).attr("data-module_id");
		approve_all = true;
		$( ".m_check_field_"+module_id ).each(function( index ) {
			$( this ).bootstrapSwitch('state', state);
		});
		approve_all = false;
	});

	$('.module_field').on('switchChange.bootstrapSwitch', function (event, state) {//alert('dgf');
		if(approve_all){return false;}
		approve_field = true;
		var module_id = $(this).attr("data-module_id");
		var status = false;
		var total_count = 0;
		var true_count = 0;
		var false_count = 0;
		$( ".m_check_field_"+module_id ).each(function( index ) {
			total_count++;
			if($( this ).bootstrapSwitch('state'))
			{ true_count++; }
			else
			{ false_count++; }
		});
		if(true_count == total_count)
		{
			$( ".m_check_all_"+module_id ).bootstrapSwitch('state', true);
		}

		else if(false_count == total_count)
		{
			$( ".m_check_all_"+module_id ).bootstrapSwitch('state', false);
		}
		else 
		{
			$( ".m_check_all_"+module_id ).bootstrapSwitch('state', true);
		}
	//	console.log(true_count+' : '+false_count+' : '+total_count);
		approve_field = false;
	});
})
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravelapi\resources\views/dashboard/role-manager/create.blade.php ENDPATH**/ ?>