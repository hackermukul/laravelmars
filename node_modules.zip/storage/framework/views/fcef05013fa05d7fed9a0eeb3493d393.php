<?php $__env->startSection('title', __('Not Found')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', __('we are sorry, but the page you requested was not found')); ?>
<?php $__env->startSection('test', __('Page Not Found')); ?>


<?php echo $__env->make('errors.minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelmars\resources\views/errors/404.blade.php ENDPATH**/ ?>