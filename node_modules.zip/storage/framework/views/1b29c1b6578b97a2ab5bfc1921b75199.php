<a href="/">
   <img src="<?php echo e(config('constants.options.__IMAGE__').'rad.png'); ?>" >
</a>
<?php /**PATH C:\xampp\htdocs\laravelapi\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>